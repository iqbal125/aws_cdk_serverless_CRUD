export declare const handler: () => Promise<any>;
