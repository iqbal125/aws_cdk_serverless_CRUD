export declare const shandler: (event?: any) => Promise<any>;
