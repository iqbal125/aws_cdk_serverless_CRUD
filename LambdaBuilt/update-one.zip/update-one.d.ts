export declare const handler: (event?: any) => Promise<any>;
